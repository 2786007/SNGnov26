# Shree Nayra Group

Official website — Arun Kaul · IRDAI POSP #487

**Live:** https://shreenayragroup.netlify.app/

## Deploy
Connect this repo to Netlify. Publish directory = site root (index.html at root). No build command.
